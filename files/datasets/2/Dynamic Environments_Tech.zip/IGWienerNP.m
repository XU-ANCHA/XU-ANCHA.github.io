function out=IGWienerNP(Obs,opt)
% 
% Obs: the degradation observations, a K-length array
% each element of Obs corresponds to the observation of one group
% Obs{k}: a length-2 array, the first element is an nk*1 vector 
% representing the observation times 
% the second element is an nk*mk matrix representing the degradation
% observations, where each column is the degradation of one unit.
% out={T,Lam,sigma2,zeta}
K=length(Obs);
nV=zeros(1,K);
mV=zeros(1,K);
if nargin<=1
    opt='nodisp';
end
plotloglike=0;
%% Check the data format
for k=1:1:K
    [tmp11,tmp12]=size(Obs{k}{1});
    if tmp12~=1
        fprintf('The observation times of the %d-th group is not in the correct form',k);
        return;
    end
     [tmp21,tmp22]=size(Obs{k}{2});
     if tmp11~=tmp21
         fprintf('The observation times and the observations of the %d-th group are not of the same length',k);
         return;
     end
     if tmp22<=0
         fprintf('The %d-th group does not have observations',k);
         return;
     end
     nV(k)=tmp21;
     mV(k)=tmp22;
end
%% Find all the distinct observation times
tmpT=zeros(max(nV),K);
for k=1:1:K
    tmpT(1:nV(k),k)=Obs{k}{1};
end
[T,~,tId]=unique(tmpT);
if T(1)==0
    T=T(2:end);
    tId=tId-1;
end
L=length(T);
T0=[0;T(1:L-1)];
dT=T-T0;
Id=reshape(tId,max(nV),K);    %Index of the original observation times in T
deltaL=zeros(L,1);           %
for l=1:1:L
    deltaL(l)=sum(max(Id)>=l);
end
%% Initiation
tmpdX_m=zeros(max(nV),K);   %Temp matrix storing the mean of the increments 
                            %of mk units at nk time points in group k
tmpdX2_m=zeros(max(nV),K);  %mean of the square of the increments
for k=1:1:K
    tmpX=Obs{k}{2};
    tmpdX=tmpX-[zeros(1,mV(k));tmpX(1:nV(k)-1,:)];
    tmpdX_m(1:nV(k),k)=mean(tmpdX,2);
    tmpdX2_m(1:nV(k),k)=mean(tmpdX.^2,2);
end
myflag='increasing';
if sum(sum(tmpdX_m*diag(mV)))<0
    tmpdX_m=-tmpdX_m;
    myflag='decreasing';
end
tmpfunc=@(sigma2) sum(sum(1/2*(-sigma2+sqrt(sigma2^2+4*tmpdX2_m))*diag(mV)))...
    -sum(sum(tmpdX_m*diag(mV)));
tmpg=@(sigma2) sum(sum(1/2*(sigma2./sqrt(sigma2^2+4*tmpdX2_m)-1)*diag(mV)));
sigma2_0=fzeroNR(0,tmpfunc,tmpg);
dtLam=(sqrt(sigma2_0^2+4*tmpdX2_m)-sigma2_0)/2;     %dLambda_tilde
tmpdLam=zeros(L,K);
for k=1:1:K
    tmpI=[0;Id(1:nV(k),k)];
    for ki=1:1:nV(k)
        tmpdLam(tmpI(ki)+1:tmpI(ki+1),k)=...
            dT(tmpI(ki)+1:tmpI(ki+1))/sum(dT(tmpI(ki)+1:tmpI(ki+1)))*dtLam(ki,k);
    end
end
dLam0=sum(tmpdLam,2)./sum((tmpdLam>0),2);
zeta0=1e-6;
%
myobs=Obs;
if isequal(myflag,'decreasing')
    for k=1:1:K
        myobs{k}{2}=-myobs{k}{2};
    end
end
if plotloglike==1
    estpara=struct('zeta',zeta0,'sigma2',sigma2_0,'dLam',dLam0);
    loglike0=IGWienerNP_lnL(myobs,estpara);
    hold on;
    plot(0,loglike0,'ro');
end
%% EM algorithm
tol_EM=1e-10;
ite_EM=10000;
for ite=1:1:ite_EM
    EtdG=zeros(max(nV),K);      % indices are according to the local time 
    EtdG_1=zeros(max(nV),K);
    EdG=zeros(L,K);             % indices are according to the global time
    EdG_1=zeros(L,K);
    for k=1:1:K
        % generate dtLam from dLam0
        Lam0=cumsum(dLam0);
        tLam=Lam0(Id(1:nV(k),k));
        dtLam=tLam-[0;tLam(1:nV(k)-1)];
        ak=sigma2_0+zeta0*mV(k);
        bk=sigma2_0*dtLam.^2+zeta0*tmpdX2_m(:,k)*mV(k);
        vk=-(mV(k)+1)/2;
        tmpBK=Rbesselk(vk+1,sqrt(ak*bk)/zeta0/sigma2_0);
        EtdG(1:nV(k),k)=sqrt(bk/ak).*tmpBK;
        EtdG_1(1:nV(k),k)=sqrt(ak./bk).*tmpBK-2*vk./bk*sigma2_0*zeta0;
        tmpI=[0;Id(1:nV(k),k)];
        %
        tmpI_R=zeros(tmpI(end),1);      %reverse index
        tmpI_R(tmpI(2:end))=(1:nV(k))';  
        for ki=1:1:nV(k)
            if tmpI(ki+1)-tmpI(ki)>1
                tmpI_R(tmpI(ki)+1:tmpI(ki+1)-1)=tmpI_R(tmpI(ki+1));
            end
        end
        tmpdLam=dLam0(1:tmpI(end));
        tmpdtLam=dtLam(tmpI_R);
        EdG(1:tmpI(end),k)=tmpdLam./tmpdtLam.*EtdG(tmpI_R,k);
        EdG_1(1:tmpI(end),k)=(1./tmpdLam-1./tmpdtLam)./tmpdLam*zeta0...
            +tmpdtLam./tmpdLam.*EtdG_1(tmpI_R,k);
    end
    %{
      %!!!!!!!!!!!!!wrong!!!!!!!!!!!!!!!!!
%     alphaL=sum(EdG_1,2)./deltaL;
%     betaL=sum(EdG,2)./deltaL;
%     zeta1=(sum(betaL-1./alphaL)/sum(alphaL.^(-1/2)))^2;
%     funch=@(zeta) sum(sqrt(1+4*zeta*alphaL)./alphaL)-2*sum(betaL)+sum(1./alphaL);
%     funcdh=@(zeta) sum(2./sqrt(1+4*zeta*alphaL));
%     zeta1=fzeroNR(zeta1,funch,funcdh);
%     dLam1=(1+sqrt(1+4*zeta1*alphaL))./alphaL/2;
    %}
    %{
    %!!!!!!!!!!!!!right!!!!!!!!!!!!!!!!!
    alphaL=sum(EdG_1,2);
    betaL=sum(EdG,2);
    zeta1=(sum(betaL-deltaL.^2./alphaL)/sum(deltaL.^(3/2).*alphaL.^(-1/2)))^2;
    funch=@(zeta) sum(deltaL.*(deltaL+sqrt(deltaL.^2+4*zeta*alphaL.*deltaL))./alphaL)/2-sum(betaL);
    funcdh=@(zeta) sum(deltaL./sqrt(1+4*zeta*alphaL./deltaL));
    zeta1=fzeroNR(zeta1,funch,funcdh);
    dLam1=(deltaL+sqrt(deltaL.^2+4*zeta1*alphaL.*deltaL))./alphaL/2;
    %}
    %
    alphaL=deltaL./sum(EdG_1,2);
    betaL=sum(EdG,2)./deltaL;
    zeta1=(sum(deltaL.*(betaL-alphaL))/sum(deltaL.*(alphaL.^(1/2))))^2;
    funch=@(zeta) sum(deltaL.*(sqrt(alphaL.*(alphaL+4*zeta))-2*betaL+alphaL));
    funcdh=@(zeta) sum(2*deltaL.*sqrt(alphaL./(alphaL+4*zeta)));
    zeta1=fzeroNR(zeta1,funch,funcdh);
    dLam1=(alphaL+sqrt(alphaL.*(alphaL+4*zeta1)))/2;
    %}
    sigma2_1=sum(sum((EtdG-2*tmpdX_m+tmpdX2_m.*EtdG_1)*diag(mV)))/sum(nV.*mV);
    diff=sum(abs(dLam0-dLam1))+abs(zeta1-zeta0)+abs(sigma2_1-sigma2_0);
    if diff<tol_EM
        break;
    else
        dLam0=dLam1;
        zeta0=zeta1;
        sigma2_0=sigma2_1;
        if plotloglike==1
            estpara=struct('zeta',zeta0,'sigma2',sigma2_0,'dLam',dLam0);
            loglike0=IGWienerNP_lnL(myobs,estpara);
    %         hold on;
            plot(ite,loglike0,'ro');
        end
    end
end
%% Returned Results and Displayed Information
estpara=struct('zeta',zeta1,'sigma2',sigma2_1,'dLam',dLam1);
loglike=IGWienerNP_lnL(myobs,estpara);
if isequal(myflag,'decreasing')
    dLam1=-dLam1;
end
out={T,cumsum(dLam1),sigma2_1,zeta1,loglike};
if isequal(opt,'disp')
    dispstring=['Semiparametric Wiener model with Inverse Gaussian Transformtion:\n ',...
        'path Lambda: see the figure\n sigma2 =%#8.4e\n zeta =%#8.4e\n loglikelihood=%#8.4f\n ',...
        'EM stop tolerance=%#8.4e\n No. of iteration =%#8.4f\n'];
    fprintf(dispstring,out{3},out{4},out{5},diff,ite);
    %
%     figure new;
    hold on;
    mycolor=(linspace(0.5,0.9,K))'*[1,1,1];
    for k=1:1:K
        for kj=1:1:mV(k)
            plot(Obs{k}{1},Obs{k}{2}(:,kj),'color',mycolor(k,:));
        end
    end
    plot(T,cumsum(dLam1),'r-.s','linewidth',1.5);
    box on;
    xlabel('Time','fontname','Times New Roman','fontsize',11);
    ylabel('Expected TSTF(estimated)','fontname','Times New Roman','fontsize',11);
    set(gca,'fontname','Times New Roman','fontsize',11);
    set(gcf,'color','white');
end

%%
    function x1=fzeroNR(x0,func,g)
        % Newton-Raphson
        tol=1e-10;
        maxite=100;
        for ii=1:1:maxite
            x1=x0-func(x0)/g(x0);
            if abs(x1-x0)<tol
                break;
            else
                x0=x1;
            end
        end
    end
end
    