function [scoreV,infoM]=IGWienerP_infoM(Obs,estP,Lam)
%% 
% Information matrix using analytical method, i.e., second order
% derivatives
%
% The model is X(t)=H(t)+sigmaB((t))
% H(t)~IG(beta*Lam(t),zeta^(-1)*beta^2*Lam^2(t))
% where Lam(t) is a determined function, e.g. Lam(t)=t^2
%
% Note originally (in the following) we used the model
% X(t)=beta*H(t)+sigmaB((t)),H(t)~IG(Lam(t),zeta^(-1)*Lam(t)^2)
% So, there should be some transformation between these two models
%
% lnlike=IGWiener_lnL(T,X,estP);
% if nargout<=1
%     return;
% end
%
Lflag='nonlinear';
n=length(Obs);
sigma2=estP.sigma2;
beta=estP.beta;
zeta=estP.zeta;
try 
    alpha=estP.alpha;
catch exception
    alpha=1;
    Lflag='linear';
end
try 
    func_Lambda=@(t) Lam.funcS(t,alpha);
    func_pLambda=@(t) Lam.funcdS_da(t,alpha);
    func_ppLambda=@(t) Lam.funcddS_da2(t,alpha);
catch exceptions 
    if isequal(Lflag,'linear')
         % linear
        func_Lambda=@(t) t;
        func_pLambda=@(t) zeros(size(t));
        func_ppLambda=@(t) zeros(size(t));
    else
        % power law
        func_Lambda=@(t) t.^alpha;
        func_pLambda=@(t) (t.^alpha).*log(t);
        func_ppLambda=@(t) (t.^alpha).*(log(t).^2);
        % exponential
        % func_Lambda=@(t) (1-exp(alpha*t));
        % func_pLambda=@(t) -t.*exp(alpha*t);
        % func_ppLambda=@(t) -t.^2.*exp(alpha*t);
        %
    end
end
%
if isequal(Lflag,'linear')
    scoreV=zeros(3,1);
    infoM=zeros(3,3);
else
    scoreV=zeros(4,1);
    infoM=zeros(4,4);
end
omega=sigma2;
for i=1:n
    X=Obs{i}{2};
    T=Obs{i}{1};
    Lam=func_Lambda(T);
    dLam=Lam-[0;Lam(1:end-1)];
    % consider the coefficient beta
    Lam0=beta*Lam;
    dLam0=dLam*beta;
    [K,M]=size(X);
    p=-(M+1)/2;
    dX=X-[zeros(1,M);X(1:K-1,:)];
    sumXK=sum(X(K,:));
    Lam0K=Lam0(end);
    Yk=sum(dX.^2,2)/M;
    %
    a=1/zeta+M/omega;
    b=dLam0.^2/zeta+M*Yk/omega;
    a_b=(omega+M*zeta)./(omega*dLam0.^2+M*Yk*zeta);
    b_a=(omega*dLam0.^2+M*Yk*zeta)./(omega+M*zeta);
    z=sqrt(a.*b);
%% score
%
    r_posi_1=sqrt(b_a).*besselk(p+1,z)./besselk(p,z);
    r_nega_1=sqrt(a_b).*besselk(p-1,z)./besselk(p,z);
    V_omega=M/2/omega^2*(r_posi_1+Yk.*r_nega_1);
    V_zeta=1/2/zeta^2*(r_posi_1+dLam0.^2.*r_nega_1);
    V_Lam=-dLam0/zeta.*r_nega_1;
    ell_omega=-M*K/2/omega-sumXK/omega^2+sum(V_omega);
    ell_zeta=-K/2/zeta-Lam0K/zeta^2+sum(V_zeta);
    ell_beta=sum((1./dLam0+1/zeta+V_Lam).*dLam);
    if isequal(Lflag,'linear')
        tmp_scoreV=[ell_beta;ell_omega;ell_zeta];
    else
        pLam=func_pLambda(T);
        dpLam=pLam-[0;pLam(1:end-1)];
        ell_alpha=sum((1./dLam0+1/zeta+V_Lam).*(beta.*dpLam));
        tmp_scoreV=[ell_beta;ell_omega;ell_zeta;ell_alpha];
    end
    scoreV=scoreV+tmp_scoreV;
    % disp(scoreV);
    if nargout<=1
        continue;
    end
%% Information matrix
%
    r_posi_2=b_a.*besselk(p+2,z)./besselk(p,z);
    r_nega_2=a_b.*besselk(p-2,z)./besselk(p,z);
    V_omega_omega=M^2*Yk/2/omega^4-2/omega*V_omega-V_omega.^2+M^2/4/omega^4*(r_posi_2+Yk.^2.*r_nega_2);
    V_omega_zeta=M*(Yk+dLam0.^2)/4/omega^2/zeta^2-V_omega.*V_zeta+M/4/omega^2/zeta^2.*(r_posi_2+Yk.*dLam0.^2.*r_nega_2);
    V_zeta_zeta=dLam0.^2/2/zeta^4-2/zeta.*V_zeta-V_zeta.^2+1/4/zeta^4*(r_posi_2+dLam0.^4.*r_nega_2);
    V_omega_Lam=-M*dLam0/2/omega^2/zeta-V_omega.*V_Lam-M*Yk.*dLam0/2/omega^2/zeta.*r_nega_2;
    V_zeta_Lam=-dLam0/2/zeta^3-1/zeta*V_Lam-V_zeta.*V_Lam-dLam0.^3/2/zeta^3.*r_nega_2;
    V_Lam_Lam=1./dLam0.*V_Lam-V_Lam.^2+dLam0.^2/zeta^2.*r_nega_2;
    %
    ell_omega_omega=M*K/2/omega^2+2*sumXK/omega^3+sum(V_omega_omega);
    ell_omega_zeta=sum(V_omega_zeta);
    ell_zeta_zeta=K/2/zeta^2+2*Lam0K/zeta^3+sum(V_zeta_zeta);
    ell_omega_beta=sum(V_omega_Lam.*dLam);
    ell_zeta_beta=sum((-1/zeta^2+V_zeta_Lam).*dLam);
    ell_beta_beta=sum((-1./dLam0.^2+V_Lam_Lam).*(dLam.^2));
    %
    %
    if isequal(Lflag,'linear')
        tmp_infoM=-[ell_beta_beta,ell_omega_beta,ell_zeta_beta;...
            ell_omega_beta,ell_omega_omega,ell_omega_zeta;...
            ell_zeta_beta,ell_omega_zeta,ell_zeta_zeta];
    else
        ppLam=func_ppLambda(T);
        dppLam=ppLam-[0;ppLam(1:end-1)];
        ell_omega_alpha=sum(V_omega_Lam.*(beta*dpLam));
        ell_zeta_alpha=sum((-1/zeta^2+V_zeta_Lam).*(beta*dpLam));
        ell_beta_alpha=sum((-1./dLam0.^2+V_Lam_Lam).*dLam.*(beta*dpLam)+(1./dLam0+1/zeta+V_Lam).*dpLam);
        ell_alpha_alpha=sum((-1./dLam0.^2+V_Lam_Lam).*((beta*dpLam).^2)+(1./dLam0+1/zeta+V_Lam).*(beta*dppLam));
        tmp_infoM=-[ell_beta_beta,ell_omega_beta,ell_zeta_beta,ell_beta_alpha;...
            ell_omega_beta,ell_omega_omega,ell_omega_zeta,ell_omega_alpha;...
            ell_zeta_beta,ell_omega_zeta,ell_zeta_zeta,ell_zeta_alpha;...
            ell_beta_alpha,ell_omega_alpha,ell_zeta_alpha,ell_alpha_alpha];
    end
    infoM=infoM+tmp_infoM;
end
end