function out=IGWienerP(Obs,Lam,dispflag)
% Parametric IG-Wiener process with power law path, Lam(t)=beta*x^alpha
% Obs: the degradation observations, a K-length array
% each element of Obs corresponds to the observation of one group
% Obs{k}: a length-2 array, the first element is an nk*1 vector 
% representing the observation times 
% the second element is an nk*mk matrix representing the degradation
% observations, where each column is the degradation of one unit.
% out={beta,alpha,sigma2,zeta}
if nargin<=2
    dispflag='nodisp';
end
linearflag=0;
try 
    funcS=Lam.funcS;
    funcdS_da=Lam.funcdS_da;
    try
        alpha0=Lam.alpha0;
    catch exceptions
        alpha0=1;
    end
    try 
        funcPara=Lam.funcPara;
        %�ú�����Ҫ���ڵ������յ����������ֵ������funcS��һ���Ǽ򵥵��ݺ�����ָ�������
            %�����Դ�ϵ�����ú������Խ���������ϵ������Ϊ��׼��
            %X(t)=H(t)+sigma*B(H(t)), H(t)~IG(beta*S(t),zeta*beta^2*S^2(t))��ʽ
            %
        stringS=Lam.str_S;%S����ʽ
    catch exceptions
        funcPara=@(beta,alpha,sigma2,zeta) [beta,alpha,sigma2,zeta];
        stringS=strcat('S(t)=',char(funcS));
    end
catch exceptions
    % -------linear-------
    linearflag=1;
    funcS=@(t,a) t;
    alpha0=1;
    funcPara=@(beta,alpha,sigma2,zeta) [beta,alpha,sigma2,zeta];
    stringS='S(t)=t';
    % -------power law-------
%     funcS=@(t,a) t.^a;
%     funcdS_da=@(t,a) t.^a.*log(t);
%     funcPara=@(beta,alpha,sigma2,zeta) [beta,alpha,sigma2,zeta];
%     alpha0=1;
    % -------logorithm-------
    % funcS=@(t,a) log(a*t+1);
    % funcdS_da=@(t,a) t./(a*t+1);
    % funcPara=@(beta,alpha,sigma2,zeta) [beta,alpha,sigma2,zeta];
    % -------exponential law-------
%     SELECT=@(FUNCARRAY,COND) FUNCARRAY(:,2-COND);
%     % funcS=@(t,a) SELECT([(exp(a*t)-1)/a,t],a~=0);
%     % funcdS_da=@(t,a) SELECT([exp(a*t).*t/a-(exp(a*t)-1)/a^2,t.^2/2],a~=0);
%     % funcPara=@(beta,alpha,sigma2,zeta) (SELECT([beta/alpha,alpha,sigma2,zeta;beta,alpha,sigma2,zeta]',alpha~=0))';
%     funcS=@(t,a) SELECT([(abs(a).^t-1)/log(a),t],a>0&a~=1);
%     funcdS_da=@(t,a) SELECT([abs(a).^(t-1).*t/log(abs(a))-(abs(a).^t-1)/(abs(a)*log(abs(a))^2),t.^2/2],a>0&a~=1);
%     funcddS_da2=@(t,a) SELECT([(abs(a).^t-1).*(2./(abs(a).^2.*log(abs(a)).^3)+1./(abs(a).^2.*log(abs(a)).^2))-2*abs(a).^(t-2).*t/log(abs(a)).^2+abs(a).^(t-2).*(t-1).*t./log(abs(a)),t.^2.*(2*t-3)/6],a>0&a~=1);
%     funcPara=@(beta,alpha,sigma2,zeta) (SELECT([beta/log(alpha),alpha,sigma2,zeta;beta,alpha,sigma2,zeta]',alpha>0&alpha~=1))';
%     alpha0=1;
    % -------combined logorithm&exponential-------
%     SELECT=@(FUNCARRAY,COND) FUNCARRAY(:,2-COND);
%     funcS=@(t,a) SELECT([a/(1-a)*log((1/a-1)*t+1),...
%         SELECT([t,(exp((a-1)*t)-1)/(a-1)],a==1)],a>0&a<1);
%     funcdS_da=@(t,a) SELECT([((1-a)*t+(t*(a-1)-a).*log((1/a-1)*t+1))./(t*(a-1)-a)/(1-a)^2,...
%         SELECT([t.^2/2,(1+exp((a-1)*t).*((a-1)*t-1))/(a-1)^2],a==1)],a>0&a<1);
%     funcPara=@(beta,alpha,sigma2,zeta) (SELECT([beta*alpha/(1-alpha),1/alpha-1,sigma2,zeta;...
%         (SELECT([beta,alpha,sigma2,zeta;beta/(alpha-1),alpha-1,sigma2,zeta]',alpha==1))']',alpha>0&alpha<1))';
    %------------------------
    % funcS=@(t,a) abs(SELECT([a/(1-a)*log((1/a-1)*t+1),...
    %     SELECT([t,(exp((a-1)*t)-1)/(a-1)],a==1)],a>1));
    % funcdS_da=@(t,a) abs(SELECT([((1-a)*t+(t*(a-1)-a).*log((1/a-1)*t+1))./(t*(a-1)-a)/(1-a)^2,...
    %     SELECT([t.^2/2,(1+exp((a-1)*t).*((a-1)*t-1))/(a-1)^2],a==1)],a>1));
    %-------------------------
     if ~isequal(dispflag,'nodisp')
        disp('<---------------------------->');
        disp('No functional form for the degradation trend is specified;');
        disp(strcat('A built in one with ',stringS,' is used.'));
        disp('<---------------------------->');
        disp(exceptions);
     end
end

K=length(Obs);
nV=zeros(1,K);
mV=zeros(1,K);
plotloglike=0;
%% Check the data format
for k=1:1:K
    [tmp11,tmp12]=size(Obs{k}{1});
    if tmp12~=1
        fprintf('The observation times of the %d-th group is not in the correct form',k);
        return;
    end
     [tmp21,tmp22]=size(Obs{k}{2});
     if tmp11~=tmp21
         fprintf('The observation times and the observations of the %d-th group are not of the same length',k);
         return;
     end
     if tmp22<=0
         fprintf('The %d-th group does not have observations',k);
         return;
     end
     nV(k)=tmp21;
     mV(k)=tmp22;
end
%% Find all the distinct observation times
Mask=ones(max(nV),K);
tmpT=zeros(max(nV),K);
tmpdT=zeros(max(nV),K);
for k=1:1:K
    tmpT(1:nV(k),k)=Obs{k}{1};
    tmpdT(1:nV(k),k)=tmpT(1:nV(k),k)-[0;tmpT(1:nV(k)-1,k)];
    Mask(1:nV(k),k)=0;
end
[T,~,tId]=unique(tmpT);
if T(1)==0
    T=T(2:end);
    tId=tId-1;
end
L=length(T);
% T0=[0;T(1:L-1)];
% dT=T-T0;
Id=reshape(tId,max(nV),K);    %Index of the original observation times in T
deltaL=zeros(L,1);           %
for l=1:1:L
    deltaL(l)=sum(max(Id)>=l);
end
%% Initiation
tmpdX_m=zeros(max(nV),K);   %Temp matrix storing the mean of the increments 
                            %of mk units at nk time points in group k
tmpdX2_m=zeros(max(nV),K);  %mean of the square of the increments
for k=1:1:K
    tmpX=Obs{k}{2};
    tmpdX=tmpX-[zeros(1,mV(k));tmpX(1:nV(k)-1,:)];
    tmpdX_m(1:nV(k),k)=mean(tmpdX,2);
    tmpdX2_m(1:nV(k),k)=mean(tmpdX.^2,2);
end
myflag='increasing';
if sum(sum(tmpdX_m*diag(mV)))<0
    tmpdX_m=-tmpdX_m;
    myflag='decreasing';
end
beta0=sum(mV.*sum(tmpdX_m))/sum(mV.*sum(tmpdT));
sigma2_0=(sum(mV.*sum(tmpdX2_m./(tmpdT+Mask)))-beta0*sum(mV.*sum(tmpdX_m)))/sum(mV.*nV)/beta0;
zeta0=sigma2_0/10; 
%note that the final result can depend on the initial values for the
%parameters, if so, it is highly possible that the model is not well
%identified; In other words, the model is two complicated for the data
%
% beta0=-9.5597e-004
% alpha0=8.0566e-001
% sigma2_0=3.4555e-003
% zeta0=1.6604e-003
%
myobs=Obs;
if isequal(myflag,'decreasing')
    for k=1:1:K
        myobs{k}{2}=-myobs{k}{2};
    end
end
if plotloglike==1
    estpara=struct('zeta',zeta0,'sigma2',sigma2_0,'alpha',alpha0,'beta',beta0);
    loglike0=IGWienerP_lnL(myobs,estpara,funcS);
    hold on;
    plot(0,loglike0,'ro');
end
%% EM algorithm
tol_EM=1e-12;
ite_EM=1000;
for ite=1:1:ite_EM
    EtdG=zeros(max(nV),K);      % indices are according to the local time 
    EtdG_1=zeros(max(nV),K);
    EdG=zeros(L,K);             % indices are according to the global time
    EdG_1=zeros(L,K);
    for k=1:1:K
        % generate dtLam
        Lam0=beta0*funcS(T,alpha0);
        dLam0=Lam0-[0;Lam0(1:end-1)];
        tLam=beta0*funcS(tmpT(1:nV(k),k),alpha0);
        dtLam=tLam-[0;tLam(1:nV(k)-1)];
        ak=sigma2_0+zeta0*mV(k);
        bk=sigma2_0*dtLam.^2+zeta0*tmpdX2_m(:,k)*mV(k);
        vk=-(mV(k)+1)/2;
%         tmpBK=Rbesselk(vk+1,sqrt(ak*bk)/zeta0/sigma2_0);
        tmpBK=besselk(vk+1,sqrt(ak*bk)/zeta0/sigma2_0)./besselk(vk,sqrt(ak*bk)/zeta0/sigma2_0);
        EtdG(1:nV(k),k)=sqrt(bk/ak).*tmpBK;
        EtdG_1(1:nV(k),k)=sqrt(ak./bk).*tmpBK-2*vk./bk*sigma2_0*zeta0;
        tmpI=[0;Id(1:nV(k),k)];
        %
        tmpI_R=zeros(tmpI(end),1);      %reverse index
        tmpI_R(tmpI(2:end))=(1:nV(k))';  
        for ki=1:1:nV(k)
            if tmpI(ki+1)-tmpI(ki)>1
                tmpI_R(tmpI(ki)+1:tmpI(ki+1)-1)=tmpI_R(tmpI(ki+1));
            end
        end
        tmpdLam=dLam0(1:tmpI(end));
        tmpdtLam=dtLam(tmpI_R);
        EdG(1:tmpI(end),k)=tmpdLam./tmpdtLam.*EtdG(tmpI_R,k);
        EdG_1(1:tmpI(end),k)=(1./tmpdLam-1./tmpdtLam)./tmpdLam*zeta0...
            +tmpdtLam./tmpdLam.*EtdG_1(tmpI_R,k);
    end
    options=optimset('Display','off','TolX',1e-8,'TolFun',1e-12);
    if linearflag==1
        alpha1=1;
    else
        alpha1=fsolve(@TempEq,alpha0,options);
    end
    tmpdG_s=sum(EdG,2);
    tmpdG_ss=sum(tmpdG_s);
    tmpdG_1_s=sum(EdG_1,2);
    tmpdT_alpha=funcS(T,alpha1)-[0;funcS(T(1:end-1),alpha1)];
    beta1=tmpdG_ss/sum(deltaL.*tmpdT_alpha);
    zeta1=(beta1^2*sum(tmpdT_alpha.^2.*tmpdG_1_s)-tmpdG_ss)/sum(deltaL);
    %}
    sigma2_1=sum(sum((EtdG-2*tmpdX_m+tmpdX2_m.*EtdG_1)*diag(mV)))/sum(nV.*mV);
    diff=sum(abs(beta0-beta1))+abs(alpha0-alpha1)+abs(zeta1-zeta0)+abs(sigma2_1-sigma2_0);
    if diff<tol_EM
        break;
    else
        beta0=beta1;
        alpha0=alpha1;
        zeta0=zeta1;
        sigma2_0=sigma2_1;
        if plotloglike==1
            estpara=struct('zeta',zeta0,'sigma2',sigma2_0,'alpha',alpha0,'beta',beta0);
            loglike0=IGWienerP_lnL(myobs,estpara,funcS);
    %         hold on;
            plot(ite,loglike0,'ro');
        end
    end
end
%% Returned Results and Displayed Information
estpara=struct('zeta',zeta1,'sigma2',sigma2_1,'alpha',alpha1,'beta',beta1);
loglike=IGWienerP_lnL(myobs,estpara,funcS);
if isequal(myflag,'decreasing')
    beta1=-beta1;
end
if linearflag==0
    out=[funcPara(beta1,alpha1,sigma2_1,zeta1),loglike];
    if isequal(dispflag,'disp')
        dispstring=['Parametric Wiener model with Inverse Gaussian Transformtion:\n ',...
            'The degradation trend form is ',stringS,'\n ',...
            ' beta =%#8.4e\n  alpha =%#8.4e\n  sigma2 =%#8.4e\n  zeta =%#8.4e\n  loglikelihood=%#8.4f\n  ',...
            'EM stop tolerance=%#8.4e\n  No. of iteration =%#8.4f\n'];
        fprintf(dispstring,out(1),out(2),out(3),out(4),out(5), diff,ite);
    end
else
    out=[beta1,sigma2_1,zeta1,loglike];
    if isequal(dispflag,'disp')
        dispstring=['Parametric Wiener model with Inverse Gaussian Transformtion:\n ',...
            'The degradation trend form is simple linear\n  ',...
            'beta =%#8.4e\n  sigma2 =%#8.4e\n  zeta =%#8.4e\n  loglikelihood=%#8.4f\n  ',...
            'EM stop tolerance=%#8.4e\n  No. of iteration =%#8.4f\n'];
        fprintf(dispstring,out(1),out(2),out(3),out(4),diff,ite);
    end
end
if isequal(dispflag,'disp')
    hold on;
    mycolor=(linspace(0.5,0.9,K))'*[1,1,1];
    for k=1:1:K
        for kj=1:1:mV(k)
            plot(Obs{k}{1},Obs{k}{2}(:,kj),'color',mycolor(k,:));
        end
    end
    Tplot=(linspace(0,T(end),50))';
    plot(Tplot,beta1*funcS(Tplot,alpha1),'r-.','linewidth',1.5);
    box on;
    xlabel('Time','fontname','Times New Roman','fontsize',11);
    ylabel('Expected TSTF(estimated)','fontname','Times New Roman','fontsize',11);
    set(gca,'fontname','Times New Roman','fontsize',11);
    set(gcf,'color','white');
end

%%
    function y=TempEq(a)
        EdG_s=sum(EdG,2);
        EdG_ss=sum(EdG_s);
        EdG_1_s=sum(EdG_1,2);
        delta_s=sum(deltaL);
        Lg=length(a);
        y=zeros(size(a));
        for ii=1:Lg
            S=funcS(T,a(ii));
            s=S-[0;S(1:end-1)];
            dS=funcdS_da(T,a(ii));
            ds=dS-[0;dS(1:end-1)];
            beta=EdG_ss/sum(deltaL.*s);
            z1=(beta^2*sum(s.^2.*EdG_1_s)-EdG_ss)/delta_s;
            z2=(beta^2*sum(s.*ds.*EdG_1_s)-beta*sum(ds.*deltaL))...
                /sum(ds./s.*deltaL);
            y(ii)=z2-z1;
        end
    end
end
    