function res=IGWienerNP_lnL(Obs,estpara)
% loglikelihood for nonparametric estimation of IGWiener model
% Must be cautious about that: we consider an increasing trend, so dLam>0
%% Estimated parameters
sigma2=estpara.sigma2;
zeta=estpara.zeta;
dLam=estpara.dLam;
L=length(dLam);
K=length(Obs);
%% Check the data format
nV=zeros(1,K);
mV=zeros(1,K);
for k=1:1:K
    [tmp11,tmp12]=size(Obs{k}{1});
    if tmp12~=1
        fprintf('The observation times of the %d-th group is not in the correct form',k);
        return;
    end
     [tmp21,tmp22]=size(Obs{k}{2});
     if tmp11~=tmp21
         fprintf('The observation times and the observations of the %d-th group are not of the same length',k);
         return;
     end
     if tmp22<=0
         fprintf('The %d-th group does not have observations',k);
         return;
     end
     nV(k)=tmp21;
     mV(k)=tmp22;
end
%% Find all the distinct observation times
tmpT=zeros(max(nV),K);
for k=1:1:K
    tmpT(1:nV(k),k)=Obs{k}{1};
end
[T,~,tId]=unique(tmpT);
if T(1)==0
    T=T(2:end);
    tId=tId-1;
end
if length(T)~=L
    disp('The length of overall measurement time points is not same with that of estimated dLam');
    res=0;
    return;
end
Id=reshape(tId,max(nV),K);    %Index of the original observation times in T
%% Loglikelihood
lnL=zeros(1,K);
for k=1:1:K
    tmpI=[0;Id(1:nV(k),k)];
    dtLam=zeros(nV(k),1);
    X=Obs{k}{2};
    dX=X-[zeros(1,mV(k));X(1:nV(k)-1,:)];
    sumdX=sum(dX,2);
    sumdX2=sum(dX.^2,2);
%     tmplnL=zeros(nV(k),1);
    for ki=1:1:nV(k)
        dtLam(ki)=sum(dLam(tmpI(ki)+1:tmpI(ki+1)));
    end
    if zeta==0
        lnL(k)=-nV(k)*mV(k)/2*log(2*pi*sigma2)-mV(k)/2*sum(log(dtLam))...
            -sum(sum((dX-dtLam*ones(1,mV(k))).^2./2/sigma2./(dtLam*ones(1,mV(k)))));
    else
        ak=sigma2+zeta*mV(k);
        bk=dtLam.^2*sigma2+zeta*sumdX2;
        vk=-(mV(k)+1)/2;
        lnL(k)=nV(k)*(log(2)+vk*log(2*pi))+sum(log(dtLam))-nV(k)/2*log(zeta)...
            -nV(k)*mV(k)/2*log(sigma2)-vk/2*sum(log(ak./bk))...
            +sum(dtLam/zeta+sumdX/sigma2-sqrt(ak.*bk)/zeta/sigma2)...
            +sum(log(besselmx(double('K'),vk,sqrt(ak*bk)/zeta/sigma2,1)));
%         lnL(k)=-nV(k)*mV(k)/2*log(2*pi*sigma2)-mV(k)/2*sum(log(dtLam))...
%             -sum(sumdX2./dtLam-2*sumdX+mV(k)*dtLam)/2/sigma2...
%             +(mV(k)+1)/4*sum(log((sigma2+zeta*mV(k))./(sigma2+zeta*sumdX2./dtLam.^2)))...
%             +sum((dtLam/zeta+(sumdX2./dtLam+mV(k)*dtLam)/2/sigma2-sqrt(ak.*bk)/zeta/sigma2))...
%             +sum(log(sqrt(2*dtLam/pi/zeta).*besselmx(double('K'),vk,sqrt(ak*bk)/zeta/sigma2,1)));
    end
end
res=sum(lnL);
end