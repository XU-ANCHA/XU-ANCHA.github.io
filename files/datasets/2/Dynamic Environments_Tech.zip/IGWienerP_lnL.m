function res=IGWienerP_lnL(Obs,estpara,funcS)
% loglikelihood for Parametric estimation of IGWiener model with parametric
% models
% X(t)=H(t)+W(H(t))
% H(t)~IG(Lam(t),zeta^(-1)*Lam(t)^2);
% Lam(t)=beta*S(t), S(t) can have various form
% betast be cautious about that: we consider an increasing trend, so beta>0
%
%% Estimated parameters
sigma2=estpara.sigma2;
zeta=estpara.zeta;
beta=estpara.beta;
try
    alpha=estpara.alpha;
catch
    alpha=1;
end
if nargin<3
% -------linear-------
funcS=@(t,a) t;
% -------power law-------
% funcS=@(t,a) t.^a;
% -------logorithm-------
% funcS=@(t,a) log(a*t+1);
% -------exponential law-------
% SELECT=@(FUNCARRAY,COND) FUNCARRAY(:,2-COND);
% % funcS=@(t,a) SELECT([(exp(a*t)-1)/a,t],a~=0);
% funcS=@(t,a) SELECT([(abs(a).^t-1)/log(abs(a)),t],abs(a)~=1);
% -------combined logorithm&exponential-------
% SELECT=@(FUNCARRAY,COND) FUNCARRAY(:,2-COND);
% funcS=@(t,a) SELECT([a/(1-a)*log((1/a-1)*t+1),...
%     SELECT([t,(exp((a-1)*t)-1)/(a-1)],a==1)],a>0&a<1);
% -------------------------------------------------
% funcS=@(t,a) abs(SELECT([a/(1-a)*log((1/a-1)*t+1),...
%     SELECT([t,(exp((a-1)*t)-1)/(a-1)],a==1)],a>1));
% -------------------------------------------
end
K=length(Obs);
%% Check the data format
nV=zeros(1,K);
mV=zeros(1,K);
for k=1:1:K
    [tmp11,tmp12]=size(Obs{k}{1});
    if tmp12~=1
        fprintf('The observation times of the %d-th group is not in the correct form',k);
        return;
    end
     [tmp21,tmp22]=size(Obs{k}{2});
     if tmp11~=tmp21
         fprintf('The observation times and the observations of the %d-th group are not of the same length',k);
         return;
     end
     if tmp22<=0
         fprintf('The %d-th group does not have observations',k);
         return;
     end
     nV(k)=tmp21;
     mV(k)=tmp22;
end
%% Loglikelihood
lnL=zeros(1,K);
if beta>0
    betaflag=1;
else
    betaflag=-1;
end
for k=1:1:K
    X=Obs{k}{2}*betaflag;
    dX=X-[zeros(1,mV(k));X(1:nV(k)-1,:)];
    sumdX=sum(dX,2);
    sumdX2=sum(dX.^2,2);
    T=Obs{k}{1};
    tLam=beta*betaflag*funcS(T,alpha);
    dtLam=tLam-[0;tLam(1:end-1)];
    if zeta==0
        lnL(k)=-nV(k)*mV(k)/2*log(2*pi*sigma2)-mV(k)/2*sum(log(dtLam))...
            -1/2/sigma2*sum(sum((dX-dtLam*ones(1,mV(k))).^2,2)./dtLam);
    else
        ak=sigma2+zeta*mV(k);
        bk=dtLam.^2*sigma2+zeta*sumdX2;
        vk=-(mV(k)+1)/2;
        lnL(k)=nV(k)*(log(2)+vk*log(2*pi))+sum(log(dtLam))-nV(k)/2*log(zeta)...
            -nV(k)*mV(k)/2*log(sigma2)-vk/2*sum(log(ak./bk))...
            +sum(dtLam/zeta+sumdX/sigma2-sqrt(ak.*bk)/zeta/sigma2)...
            +sum(log(besselk(vk,sqrt(ak*bk)/zeta/sigma2,1)));
    end
end
res=sum(lnL);
end