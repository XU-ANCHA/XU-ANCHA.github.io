function [Tp,var_Tp]=IGWienerP_Tp(estP,estPCov,d,p,S)
% The quantile T and its variance at a given p based on delta method
% R(t)=E_{H(t)}[Int_0^h{d/Sqrt[2*Pi*omega*x^3]*Exp[-(x-d)^2/2/omgea/x]}dx]
%     =Int[Lam/Sqrt[2*Pi*omega*h^3]*Exp[-(h-Lam)^2/2/zeta/h
%                           *d/Sqrt[2*Pi*omega*x^3]*Exp[-(x-d)^2/2/omgea/x]dxdh
% where d=failure threshold, Lam=expected degradation
%       omega=sigma2=variance estPmeter of X(t)
%       zeta=variance estPmeter of H(t)
%       Lam=beta*t is the expected degradation trend
Lflag='nonlinear';
try 
    alpha=estP.alpha;
catch exception
    alpha=1;
    Lflag='linear';
end
try
    funcS=S.funcS;
    funcdS_dt=S.funcdS_dt;
    funcdS_da=S.funcdS_da;
catch exception
    funcS=@(t,a) t;
    funcdS_dt=@(t,a) ones(size(t));
    funcdS_da=@(t,a) zeros(size(t));
    Lflag='linear';
end
beta=estP.beta;
omega=estP.sigma2;
zeta=estP.zeta;
IGpdf=@(x,mu,theta) sqrt(theta./(2*pi*x.^3)).*exp(-theta*(x-mu).^2/2/mu^2./x);
if zeta==0
    Ft=@(t) IGcdf(t,d,d^2/omega);
else
    Ft=@(t) quadgk(@(h) IGcdf(h,d,d^2/omega).*IGpdf(h,t,t^2/zeta),10^(-8),Inf);
end
Sp=fminsearch(@(t) (Ft(t)-p).^2,d)/beta; %p-percent lifetime under S(t;alpha)
Tp=fminsearch(@(t) (funcS(t,alpha)-Sp).^2,Sp); %p-percent lifetime under S(t;alpha)
if nargout>=2
    Lam=beta*Sp;
    % partial derivative of F(t)
    dF_omega=(-d/omega^2-1/2/omega)*p+...
        1/2/omega^2*quadgk(@(x) (1-IGcdf(x,Lam,Lam^2/zeta)).*(x+d^2./x).*IGpdf(x,d,d^2/omega),10^(-8),Inf);
    dF_zeta=(-Lam/zeta^2-1/2/zeta)*p+...
        1/2/zeta^2*quadgk(@(h) IGcdf(h,d,d^2/omega).*(h+Lam^2./h).*IGpdf(h,Lam,Lam^2/zeta),10^(-8),Inf);
    dF_Lam=((1/Lam+1/zeta)*p-Lam/zeta*quadgk(@(h) IGcdf(h,d,d^2/omega).*IGpdf(h,Lam,Lam^2/zeta)./h,10^(-8),Inf));
    dSp=([-Sp/beta,-dF_omega/(dF_Lam*beta),-dF_zeta/(dF_Lam*beta),0])';
    dTp=dSp./funcdS_dt(Tp,alpha);
    dTp(4:end)=-funcdS_da(Tp,alpha)/funcdS_dt(Tp,alpha);
    if isequal(Lflag,'linear')
        dTp=dTp(1:3);
    end
    var_Tp=dTp'*estPCov*dTp;
end
    function y=IGcdf(x,beta,theta)
        %because exp*norcdf often occur as inf*0=nan, we write our own
        %function
        % note normcdf(x,0,1)=1/2/sqrt(pi)*gammainc(x^2/2,1/2,'upper');
        y=normcdf(sqrt(theta)*(sqrt(x)/beta-x.^(-1/2)),0,1);
        if ~isnan(exp(2*theta/beta)*normcdf(-sqrt(theta)*(sqrt(x)/beta+x.^(-1/2)),0,1))
            y=y+exp(2*theta/beta)*normcdf(-sqrt(theta)*(sqrt(x)/beta+x.^(-1/2)),0,1);
        end
    end
end



